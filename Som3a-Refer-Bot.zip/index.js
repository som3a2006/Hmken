const express = require('express');
const { Telegraf, Scenes, session} = require('telegraf');
const { Stage, BaseScene, WizardScene } = Scenes;
const { MongoClient } = require('mongodb');
const mongoURI = "mongodb+srv://judgetorres:judgetorres1234@judgetorres.64yjcqg.mongodb.net/?retryWrites=true&w=majority";
const client = new MongoClient(mongoURI);
const token = '6894228689:AAHo66JtTjNn5_sfphtXkRfmKZ1z3bDdVfw';
const app = express();
const bot = new Telegraf(token);
const stage = new Stage();


const cur = "TRX";
const minWith = 1;

let db,starkNilX;
async function connectToMongo() {
   await client.connect();
  db = await client.db("Som3aReferBot");
  starkNilX = await db.collection("Users");
}
connectToMongo();

const channels = [
  "cartmoreelogs"
];

async function allUser(admin) {
   try {
     const user = await starkNilX.find({}).toArray();
     return user;
   } catch (err) {
     console.error(err);
      return null;
   }
}

async function getUser(userId) {
   try {
     const user = await starkNilX.findOne({userId: userId});
     return user;
   } catch (err) {
     console.error(err);
      return null;
   }
}

async function addUser(user) {
   try {
     const res = await starkNilX.insertOne(user);
     return res;
   } catch (err) {
     console.error(err);
      return null;
   }
}

async function updateUser(user,data) {
   try {
      const res = await starkNilX.updateOne({userId: user}, data);
     return res;
   } catch (error){
     console.log(error);
      return null;
   }

}

bot.use(session());
bot.use(stage.middleware());

async function mainMenu(ctx) {
    const userId = ctx.from.id;
    const user = await getUser(userId);
    if (!user){
      return ctx.reply("You are not registered in the database. Please use /start to register.");
    }
  if (user.verify !== true){
    ctx.reply("You have not verify your contact");
    return;
  }
  
    const txt = `
🏘 القائمة الرئيسية\n<i>تمت البرمجه من قبل SOM3A</i>
  `;
    const params = {
      parse_mode: "HTML",
      reply_markup: {
        keyboard: [
          [
            {
              text: "⚖️ رصيدك"
            }
          ],
          [
            {
              text: "دعوة الأصدقاء🧑‍🤝‍🧑"
            },
            {
              text: "🔒 Wallet"
            },
            {
              text: "🤑 السحب"
            }
          ],
          [
            {
              text: "ربح المزيد 💸",
            },
            {
              text: "المكافأة اليوميه 🎉"
            }
          ]
        ],
        resize_keyboard: true
      }
    }

  ctx.reply(txt, params);
  
  }

  bot.start(async (ctx) => {
    const userId = ctx.from.id;
    const newUser = await getUser(userId);
    if (newUser && newUser.verify === true){
      mainMenu(ctx);
      return;
    }
    let upline = null;
    let claimRef = ctx.message.text.split(" ")[1];

    if (claimRef && !isNaN(claimRef) && claimRef.length == 10 && claimRef != userId){
      upline = claimRef;
    }
    addUser({
      userId: userId,
      upline: upline,
      balance: 0,
      wallet: null,
      referral: 0,
      downlines: [],
      last_bonus_time: null,
      verify: false,
      firstDone: false,
      ban: false
    });
    const new_user_contact = new BaseScene("contact"+userId);

    new_user_contact.enter((ctx) => {
        ctx.reply(`
© شارك جهة الاتصال الخاصة بك من أجل البدء في استخدام الروبوت.  هذا مجرد التحقق من رقم الهاتف

⚠️ ملحوظه: لن نشارك جهة اتصالك مع اي احد علي الإطلاق
`,{
          parse_mode: "HTML",
          reply_markup: {
            keyboard: [
              [
                {
                  text: "Share contact",
                  request_contact: true
                }
              ]
            ],
              resize_keyboard: true,
          }
});
    });
    
    new_user_contact.on('contact',async (ctx) => {
      const contact = ctx.message.contact;
      const user = ctx.from.id;
      const phone = contact.phone_number;
      const owner = contact.user_id;
      if (owner != user){
        ctx.reply("⚠️ يبدو أن هذه ليست جهة الاتصال الخاصة بك ، يرجى النقر فوق الزر أدناه والمحاولة مرة أخرى.");
        return;
      }
      /*if (!phone.startsWith("20")){
        ctx.reply("Country number not starts with 20");
        return;
      }*/
      await ctx.scene.leave();
      
      const txt = "القنوات ، انقر فوق زر الانضمام";
      const keyboards = [];

      for (const chan of channels){
        keyboards.push([
          {
            text: "🔗 Join "+chan,
            url: "https://t.me/"+chan
          }
        ]);
      }
      keyboards.push([
        {
          text: "✅ Joined",
          callback_data: "chckchan"
        }
      ])

      ctx.reply(txt, {
        reply_markup: {
          inline_keyboard: keyboards
        }
      });
    });
    new_user_contact.use(ctx => ctx.reply("⚠️ الرجاء النقر فوق الزر أدناه لمشاركة جهة الاتصال الخاصة بك."))
    stage.register(new_user_contact);
    ctx.scene.enter("contact"+userId);
  });

bot.action("chckchan", async (ctx) =>{
  const userId = ctx.from.id;
  let c = 0;

  for (const channel of channels){
    try {
      const res = await ctx.telegram.getChatMember(`@${channel}`, userId);
      if(res.status == "left"){
        break;
      }else{
        c++
      }
    } catch (err) {
      ctx.answerCbQuery();
      ctx.reply("An error occurred while checking the channel membership. Please try again later.");
      return;
    }
  }

  if (channels.length != c){
    ctx.answerCbQuery("❌ Sorry, please join the telegram groups");
    return;
  }
  ctx.answerCbQuery();
  ctx.deleteMessage();
  await updateUser(userId,{$set: {verify: true}});
await mainMenu(ctx,ctx.callbackQuery.message.message_id);

  const mine = await getUser(userId);
  if (!mine){
    return;
  }
  const upline = mine.upline;

  await updateUser(parseFloat(upline),{$inc: {referral: 1,balance: 0.5}});
  
  ctx.telegram.sendMessage(upline,"➕ New refer just joined through your link");
  
});

bot.hears('⚖️ رصيدك', async (ctx) => {
  const userId = ctx.from.id;
  const user = await getUser(userId);

  if (!user){
    return ctx.reply("You are not registered in the database. Please use /start to register.");
  }
  const bal = user.balance;
  
  ctx.replyWithHTML("Your balance is "+bal+" "+cur);
});

bot.hears('دعوة الأصدقاء🧑‍🤝‍🧑',async ctx => {
  const userId = ctx.from.id;
  const user = await getUser(userId);

  if (!user){
    return ctx.reply("You are not registered in the database. Please use /start to register.");
  }
  const tot = user.referral;
  const refLink = "https://t.me/"+ctx.botInfo.username+"?start="+userId;
  ctx.replyWithHTML(`
Your link ${refLink}

Total Referral: ${tot} refers
`);
});

bot.hears('ربح المزيد 💸',async ctx => {
  const userId = ctx.from.id;
  const user = await getUser(userId);

  if (!user){
    return ctx.reply("You are not registered in the database. Please use /start to register.");
  }
  ctx.reply("You can earn more by referring your friends.");
});




bot.hears('المكافأة اليوميه 🎉',async ctx => {
  ctx.reply(`
🤑 احصل علي جنيه مجانيه عندما تسجل دخول كل يومياً . يمكن ان تحصل على مكافأة تقدر ب 0.06 جنيه كل 24 ساعه
`, {
    reply_markup: {
      inline_keyboard: [
        [
          {
            text: "Get Bonus",
            callback_data: "bonu"
          }
        ]
      ]
    }
});
});

bot.action("bonu",async ctx => {
  ctx.answerCbQuery();
  const userId = ctx.from.id;
  const user = await getUser(userId);
  if (!user){
    return ctx.reply("You are not registered in the database. Please use /start to register.");
  }
  let last_date = user.last_bonus_time;
  
  function canRun() {
      if (!last_date) {
        return true;
      }
      var minutes = (Date.now() - last_date) / 1000 / 60;
      var minutes_in_day = 48 * 60;
      var next = minutes_in_day - minutes;
      var wait_hours = Math.floor(next / 60);
      next -= wait_hours * 60;
      var wait_minutes = Math.floor(next);
      var seconds = Math.floor((next - wait_minutes) * 60);

      if (minutes < minutes_in_day) {
        ctx.editMessageText("*📛 You have already received a bonus Today\n\n▶️ Come Back After ⏳* " + wait_hours + " *h* " + wait_minutes + " *m* " + seconds + " *s*", {
          parse_mode: 'markdown'
        });
        return false;
      }

      return true;
    }

    if (!canRun()) {
      return;
    }

    await updateUser(userId,{
      $set: {last_bonus_time: Date.now()},
      $inc: {balance: 0.06}
    });

    ctx.editMessageText("🎉 Congrats, you Received 0.06 "+cur+" 🎊");
});

    bot.hears('🤑 السحب',async ctx => {
      const userId = ctx.from.id;
      const youtubeLink = "youtube.com/yourlink";
      let photo;
      const user = await getUser(userId);
      if (!user){
        return ctx.reply("You are not registered in the database. Please use /start to register.");
      }

      if (user && !user.firstDone){
        
        const withdraw = new BaseScene("withdraw"+userId);

        withdraw.enter((ctx) => {  
          ctx.reply("Please subscribe to our youtube channel before requesting withdrawal\n\n"+youtubeLink+" \n\nSend screenshot after subscribing \n\nFake screenshot will lead to immediate ban from tue bot");
        });
        
        withdraw.on('photo', async (ctx) => {
          await ctx.scene.leave();
          photo = ctx.message.photo[0].file_id;

          nextWithdraw(ctx,photo);
        });
        withdraw.use(ctx => ctx.reply("⚠️ Please send a screenshot after subscribing to "+youtubeLink+" youtube channel"));
      
        stage.register(withdraw);       
      ctx.scene.enter("withdraw"+userId);
        return;
      }
      nextWithdraw(ctx);
      
    });

async function nextWithdraw(ctx,photo = null) {
  const userId = ctx.from.id;
  const user = await getUser(userId);
  if (!user){
    return ctx.reply("You are not registered in the database. Please use /start to register.");
  }
  const bal = user.balance;
  const can = user.ban;
  if (can === true){
    return ctx.reply("You are banned from withdrawing in the bot");
  }
  if (bal < minWith){
    return ctx.reply("Minimum withdrawal is "+minWith+" "+cur);
  }
  const withdraw_amount = new BaseScene("withdraw_amount"+userId);

  withdraw_amount.enter((ctx) => {
    ctx.reply("Please send your withdrawal amount");
    });
  withdraw_amount.on('text',async ctx => {
    const amount = ctx.message.text;

    if (isNaN(amount)){
      return ctx.reply("Please send a valid amount");
    }
    if (amount < minWith){
      return ctx.reply("Minimum withdrawal is "+minWith+" "+cur);
    }

    if (amount > bal){
      return ctx.reply("Insufficient balance");
    }
    await ctx.scene.leave();
    updateUser(userId,{$inc: {balance: -amount}});

    ctx.reply("Your withdrawal request has been sent. Please wait for the admin to approve it.");

    if (photo){
      const txt = `
UserName: @${ctx.from.username}
UserId: ${ctx.from.id}
Amount: ${amount} ${cur}

<i>User sent subscription proff in the photo above.</i>
      `;
      const param = {
          caption: txt,
          parse_mode: "HTML"
        }
      updateUser(userId,{$set: {firstDone: true}});
      ctx.telegram.sendPhoto(6354552851, photo,param);
    }else{
      const txt = `
UserName: @${ctx.from.username}
UserId: ${ctx.from.id}
Amount: ${amount} ${cur}

<i>User have already withdraw.</i>
      `;
      ctx.telegram.sendMessage(6354552851,txt,{parse_mode: "HTML"});
    }
  });
  withdraw_amount.use((ctx) => ctx.reply("Please send a valid amount"));
  stage.register(withdraw_amount);
ctx.scene.enter("withdraw_amount"+userId);
  
}

    bot.hears('🔒 Wallet',async (ctx) => {
      const userId = ctx.chat.id;
      const user = await getUser(userId);
      if (!user){
        ctx.reply("An error occurred while retrieving user data. Please try again later.");
        return;
      }
      const wallet = user.wallet || 'not set'
      ctx.reply(`
    <b>🔍 Your currently assigned ${cur} wallet address is</b>
    <code>${wallet}</code>

    <b>💰 Please note that this wallet address will be used for all future withdrawals.</b>
    `, {
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [
              {
                text: "💼 Set / Change wallet",
                callback_data: "changeWallet"
              }
            ]
          ]
        }
    });
    });

    bot.action('changeWallet',async ctx => {
      const userId = ctx.from.id;
      const idd = ctx.callbackQuery.message.message_id;
      const add = new BaseScene("addWallet"+ctx.chat.id);

      add.enter(async (ctx) => {

        ctx.telegram.editMessageText(userId,idd,null,`
    🔘Please submit your ${cur} wallet address below.

    ⚠️Note: Please do not submit your exchange wallet address.
    `);
      });
      add.on('text', async (ctx) => {

        if (ctx.message.text.lenth < 10){
          ctx.reply("The wallet format is invalid. Please try again.");
          return;
        }
        await ctx.scene.leave();

        ctx.reply("✅ Wallet updated successfully.");
        updateUser(ctx.chat.id,{$set:{wallet: ctx.message.text}});
        mainMenu(ctx);
      });
      stage.register(add);
    ctx.scene.enter("addWallet"+ctx.chat.id);
    });



// ADMIN PART

    bot.command('totalUser',async (ctx) => {
      if(ctx.from.id != 6354552851){
         return;
       }
       const user = await allUser(ctx.from.id);
       ctx.reply(`Total Users: ${user.length}`);
    });
    bot.command('broadcast',async (ctx) => {
       if(ctx.from.id != 6354552851){
         return;
       }
      await ctx.reply("Wait fetching all user in the database...");
      const all_user = await allUser(ctx.from.id);
      await ctx.reply("All user fetched successfully");
      const broad = new BaseScene('broad');
      broad.enter(ctx => {
        ctx.reply("Enter the message you want to send");
      });
      broad.on('text', async (ctx) => {
        await ctx.scene.leave();
        await ctx.reply("Broadcasting message to all users...");

        for (const user of all_user){
          try {
             await ctx.telegram.sendMessage(user.userId,ctx.message.text);
          } catch (err) {
            console.log(err);
          }

        }

        ctx.reply("Message broadcasted successfully");

      });
      stage.register(broad);
      ctx.scene.enter('broad');
    });


bot.command("ban",async ctx => {
  if(ctx.from.id != 6354552851){
    return;
  }
  const userId = ctx.message.text.split(" ")[1];
  ctx.reply(""+userId+"");
  const user = await getUser(parseFloat(userId));
  if (!user){
    return ctx.reply("User not found");
  }
  await updateUser(parseFloat(userId),{$set: {ban: true}});
  ctx.reply("User banned successfully");
});



bot.command("unban",async ctx => {
  if(ctx.from.id != 6354552851){
    return;
  }
  const userId = ctx.message.text.split(" ")[1];
  const user = await getUser(parseFloat(userId));
  if (!user){
    return ctx.reply("User not found");
  }
  await updateUser(parseFloat(userId),{$set: {ban: false}});
  ctx.reply("User unbanned successfully");
});
/*


  try {
     db.collection("pendingWithdrawal").insertOne({
       userId: userId,
       amount: balance,
       wallet: address,
       status: "pending",
       timestamp: Date.now()
     });
  } catch (e) {
     return;
  }



*/





  bot.launch({dropPendingUpdates: true});
  app.listen(3000, () => {
    console.log('Server is running on port 3000');
  });